let header = document.getElementById("header-comp") 
header.innerHTML = 

`    <center>
<div id="div1">
<div align = "left">
<a href = "homepage.html" id="Welcome"> Welcome to my website! </a>
</div>
<header>
<div align = "right">
<button onclick="clicky1()"; class="buttons" id="home" >home</button>
<button onclick="clicky2()"; class="buttons" id="play" >play</button>
<button onclick="clicky3()"; class="buttons" id="about" >about me</button>
<button onclick="clicky4()"; class="buttons" id="log" >log out</button>
</div>
</header>

</div>
</center>

<style>
.buttons{
    margin: auto;
    background-color: #FFDBDB;
    padding: 10px;
    border-radius: 5px;
    border: 2px solid #FF8E8E;
}

.buttons:hover {
    background-color: rgb(255, 102, 102);
    color: white;
    }

#div1{
    background-color: #ffdcdc;
    width: 1300px;
    height: 90px;
  }

a{
    font-size: 30px;
    color: rgb(255, 102, 102);
}

a:link {
    color:white;
}

<div class="row">
  <div class="buttons">...</div>
  <div class="buttons">...</div>
  <div class="buttons">...</div>
</div>
  
<style/>`


function clicky1(){
    window.location.href="homepage.html";
    }
    
function clicky2(){
    window.location.href="play.html";
    }

function clicky3(){
    window.location.href="aboutme.html";
    }

function clicky4(){
    window.location.href="../index.html";
    }
        