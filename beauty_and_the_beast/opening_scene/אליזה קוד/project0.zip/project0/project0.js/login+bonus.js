signin.addEventListener("submit", (e) => {
    e.preventDefault();
  
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    
    let userDictionary = {
      "eliya@gmail": "123",
      "yaara@gmail": "456",
      "daniella@gmail": "789",
      "test": "test",
    };

    if (
      email in userDictionary && userDictionary[email] === password
    )
    {
      alert("logged in!");
        window.location.href="/project0.html/homepage.html";
    }
    else {
      alert("wrong email or password!");}

  
  });
  